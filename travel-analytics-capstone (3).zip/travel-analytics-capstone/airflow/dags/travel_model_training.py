from datetime import datetime
from airflow import DAG
from airflow.operators.bash import BashOperator

# Set TRAVEL_PROJECT_DIR in the Airflow worker/container to the mounted repository root.
PROJECT = "{{ env_var('TRAVEL_PROJECT_DIR', '/opt/travel-analytics') }}"
with DAG(
    dag_id="travel_analytics_model_training",
    description="Validate travel CSVs and retrain regression/classification models",
    start_date=datetime(2024, 1, 1),
    schedule="@weekly",
    catchup=False,
    tags=["travel", "mlops"],
) as dag:
    train_models = BashOperator(
        task_id="train_models",
        bash_command=f"cd {PROJECT} && PYTHONPATH=src python -m travel_analytics.train --data-dir data --artifact-dir artifacts",
    )
